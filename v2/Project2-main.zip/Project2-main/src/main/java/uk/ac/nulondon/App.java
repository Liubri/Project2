package uk.ac.nulondon;

public final class App {
    private App() {
    }

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
