package uk.ac.nulondon;


    import java.awt.Color;
import java.util.ArrayList;

    public class History {
        static ArrayList<Node> seamDelete;
        static ArrayList<EditingImage.Pair> deletedCoords;

        public History(ArrayList<EditingImage.Pair> deletedCoordinates, ArrayList<Node> deletedSeam) {
            deletedCoords = deletedCoordinates;
            seamDelete = deletedSeam;
        }


        public ArrayList<Node> getDeletedSeam() {
            return seamDelete;
        }


        public ArrayList<EditingImage.Pair>getDeletedCoords() {
            return deletedCoords;
        }
    }


