package uk.ac.nulondon;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import java.util.Stack;

public class EditingImage {
    //Image img;
    static Image image;
    File ogFile;
    BufferedImage oldImg;
    static int currentValueUndo;
    static BufferedImage bufferedImageUndo;
    BufferedImage newImg;
    static ArrayList<ArrayList<Integer>> energyGrid;

    static ArrayList<ArrayList<Integer>> blueGrid;
    Stack<History> newStack = new Stack<History>();

    static UserInterface user = new UserInterface();
//    private ArrayList<ArrayList<Integer>> grid;
//    static ArrayList<ArrayList<Pair>> previousSeams;
//
//    static ArrayList<ArrayList<Pair>> currentSeams;
//
//    static double[] previousValues;
//
//    double[] currentValues;

    static int counter = 0;

//    public EditingImage(Image img) {
//        this.img = img;
//    }

//    public EditingImage(ArrayList<ArrayList<Integer>> grid) {
//        this.grid = grid;
//    }

    public EditingImage(String filePath) {
        try {
            ogFile = new File(filePath);
            oldImg = ImageIO.read(ogFile);
//            width = oldImg.getWidth();
//            height = oldImg.getHeight();
        } catch (IOException e) {
            System.out.println("Error loading image: " + e.getMessage());
        }

        image = new Image(convertToDS(oldImg));
    }

    public BufferedImage getBufferImage() {
        return oldImg;
    }

    public Image getImage() {
        return image;
    }

    public static class Pair {
        int row;
        int col;

        public Pair(int row, int col) {
            this.row = row;
            this.col = col;
        }

        public String toString() {
            return "(" + row + ", " + col + ")";
        }

        public int getRow() {
            return row;
        }

        public int getCol() {
            return col;
        }
    }

    /**
     * increases count, called when highlighting, deleting, or undoing
     *
     * @return
     *
     */

    public void undoPrevEdit(boolean delete) {
        if (!newStack.isEmpty()) {
            History previous = newStack.pop();
            ArrayList<Node> deletedNodes = previous.getDeletedSeam();
            ArrayList<Pair> deletedCoords = previous.getDeletedCoords();

            if (delete) {
                History original = newStack.pop();
                ArrayList<Node> originalNodes = original.getDeletedSeam();
                ArrayList<Pair> ogCoords = original.getDeletedCoords();
                Image reinsertedImage = image.reinsertNodes(ogCoords, originalNodes);
                currentValueUndo = counter();
                bufferedImageUndo = convertToBufferImage(reinsertedImage);
            } else {
                Image reColoredImage = image.reColorNodes(deletedCoords, deletedNodes);
                currentValueUndo = counter();
                bufferedImageUndo = convertToBufferImage(reColoredImage);
            }
            if (user.isFinalVersion) {
                saveNewImage(bufferedImageUndo, currentValueUndo, false);
            } else {
                saveNewImage(bufferedImageUndo, currentValueUndo, true);
            }
        }
    }
    public int counter() {
        counter++;
        return counter;
    }

    public ArrayList<Node> convertToDS(BufferedImage image) {
        ArrayList<Node> leftColumn = new ArrayList<>();

        // Iterate over each pixel in the image
        for (int y = 0; y < image.getHeight(); y++) {
            Color colorCol = new Color(image.getRGB(0, y)); // Color of the leftmost pixel in the row
            Node leftMostNode = new Node(0, y, colorCol); // Create a new node for the leftmost pixel
            leftColumn.add(leftMostNode); // Add the leftmost node to the left column

            // Iterate over each pixel in the row (excluding the leftmost pixel)
            for (int x = 1; x < image.getWidth(); x++) {
                Color colorRow = new Color(image.getRGB(x, y)); // Color of the current pixel
                leftMostNode.addNode(x, y, colorRow); // Add a new node for the current pixel to the leftmost node
            }
        }

        return leftColumn;
    }

    /**
     * Saves the new image after every change
     * //     * @param newBuffer
     * //     * @param counter
     */

    public BufferedImage convertToBufferImage(Image img) {
        ArrayList<Node> leftmostCol = img.getLeftColumn();

        BufferedImage bufferedImage = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < img.getHeight(); y++) {
            Node current = leftmostCol.get(y);
            int x = 0;
//            for(int x = 0; x<DSwidth; x++){
            while (current != null) {
                bufferedImage.setRGB(x, y, current.getColor().getRGB());
                current = current.getNextNode();
                x++;
            }

        }
        return bufferedImage;
    }
//    public BufferedImage convertToBufferImage(ArrayList<Node> leftColumn) {
//        int DSheight = leftColumn.size();
//        int DSwidth = leftColumn.get(0).getDSWidth();
//
//        BufferedImage bufferedImage = new BufferedImage(DSwidth, DSheight, BufferedImage.TYPE_INT_RGB);
//
//        for (int y = 0; y < DSheight; y++) {
//            Node current = leftColumn.get(y);
//            int x = 0;
////            for(int x = 0; x<DSwidth; x++){
//            while (current != null) {
//                bufferedImage.setRGB(x, y, current.getColor().getRGB());
//                current = current.getNextNode();
//                x++;
//            }
//        }
//        return bufferedImage;
//    }

    /**
     * Saves the new image after every change
     *
     * @param newBuffer
     * @param counter
     */
    public void saveNewImage(BufferedImage newBuffer, int counter, boolean finalVersion) {
        try {
            if (!finalVersion) {
                // Write the BufferedImage to a PNG file
                File f = new File("src/main/resources/tempImg" + counter + ".png");
                ImageIO.write(newBuffer, "png", f);
                System.out.println("Image saved successfully");
            } else {
                File f = new File("src/main/resources/newImg" + ".png");
                ImageIO.write(newBuffer, "png", f);
                System.out.println("Image saved successfully");
            }
        } catch (IOException e) {
            System.out.println("Error with file: " + e.getMessage());
        }
    }


    /**
     * Add an element to a collection
     */
//    private static <T> ArrayList<T> concat(T element, Collection<? extends T> elements) {
//        ArrayList<T> result = new ArrayList<>();
//        result.add(element);
//        result.addAll(elements);
//        return result;
//    }
//
//    /**
//     * Method that calculates the lowest energy seam
//     * for this energy grid
//     */
//
//
//    public ArrayList<Pair> getSeam(ArrayList<ArrayList<Integer>> grid, int width, int height) {
//        previousValues = new double[width];
//        currentValues = new double[width];
//        previousSeams = new ArrayList<>();
//        currentSeams = new ArrayList<>();
//
//        Pair currentPixel = new Pair(0, 0);
//
//        int col = 0;
//
//
//        while (col < width) {
//            previousValues[col] = grid.get(0).get(col);
//
//
//            previousSeams.add(concat(currentPixel, new ArrayList<>()));
//            col++;
//            currentPixel = new Pair(currentPixel.row, currentPixel.col + 1);
//        }
//
//        // compute values and paths for each row
//        for (int row = 1; row < height; row++) {
//            col = 0;
//            currentPixel = new Pair(row, col);
//            while (col < width) {
//                double bestSoFar = previousValues[col];
//                int ref = col;
//                // check both adjacent pixels
//                // if left exists and is better, update
//                if (col > 0 && previousValues[col - 1] < bestSoFar) {
//                    bestSoFar = previousValues[col - 1];
//                    ref = col - 1;
//                }
//                // if right exists and is better, update
//                if (col < width - 1 && previousValues[col + 1] < bestSoFar) {
//                    bestSoFar = previousValues[col + 1];
//                    ref = col + 1;
//                }
//
//                // update the value with the current pixel
//                currentValues[col] = bestSoFar + grid.get(currentPixel.row).get(currentPixel.col);
//
//                // append this new pixel to existing seams
//                currentSeams.add(concat(currentPixel, previousSeams.get(ref)));
//
//                col++;
//                // move to neighbor
//                currentPixel = new Pair(currentPixel.row, currentPixel.col + 1);
//            }
//
//            // update previous values/seams
//            // and reset current values/seams
//            previousValues = currentValues;
//            currentValues = new double[width];
//            previousSeams = currentSeams;
//            currentSeams = new ArrayList<>();
//        }
//
//        // find the seam with the min sum
//        double minValue = previousValues[0];
//        int minIndex = 0;
//        for (int i = 1; i < width; i++) {
//            if (previousValues[i] < minValue) {
//                minIndex = i;
//                minValue = previousValues[i];
//            }
//        }
//        return previousSeams.get(minIndex);
//    }
//
//    public ArrayList<Pair> getHighestValueSeam(ArrayList<ArrayList<Integer>> grid, int width, int height) {
//        previousValues = new double[width];
//        currentValues = new double[width];
//        previousSeams = new ArrayList<>();
//        currentSeams = new ArrayList<>();
//
//        Pair currentPixel = new Pair(0, 0);
//
//        int col = 0;
//
//        while (col < width) {
//            previousValues[col] = grid.get(0).get(col);
//            previousSeams.add(concat(currentPixel, new ArrayList<>()));
//            col++;
//            currentPixel = new Pair(currentPixel.row, currentPixel.col + 1);
//        }
//
//        // compute values and paths for each row
//        for (int row = 1; row < height; row++) {
//            col = 0;
//            currentPixel = new Pair(row, col);
//            while (col < width) {
//                double bestSoFar = previousValues[col];
//                int ref = col;
//                // check both adjacent pixels
//                // if left exists and is better, update
//                if (col > 0 && previousValues[col - 1] > bestSoFar) {
//                    bestSoFar = previousValues[col - 1];
//                    ref = col - 1;
//                }
//                // if right exists and is better, update
//                if (col < width - 1 && previousValues[col + 1] > bestSoFar) {
//                    bestSoFar = previousValues[col + 1];
//                    ref = col + 1;
//                }
//
//                // update the value with the current pixel
//                currentValues[col] = bestSoFar + grid.get(currentPixel.row).get(currentPixel.col);
//
//                // append this new pixel to existing seams
//                currentSeams.add(concat(currentPixel, previousSeams.get(ref)));
//
//                col++;
//                // move to neighbor
//                currentPixel = new Pair(currentPixel.row, currentPixel.col + 1);
//            }
//
//            // update previous values/seams
//            // and reset current values/seams
//            previousValues = currentValues;
//            currentValues = new double[width];
//            previousSeams = currentSeams;
//            currentSeams = new ArrayList<>();
//        }
//
//        // find the seam with the max sum
//        double maxValue = previousValues[0];
//        int maxIndex = 0;
//        for (int i = 1; i < width; i++) {
//            if (previousValues[i] > maxValue) {
//                maxIndex = i;
//                maxValue = previousValues[i];
//            }
//        }
//        return previousSeams.get(maxIndex);
//    }
//
    public ArrayList<ArrayList<Integer>> energyGrid (Image img) {
        energyGrid = new ArrayList<>();
        for (int y = 0; y < img.getHeight(); y++) {
            ArrayList<Integer> rowPixels = new ArrayList<Integer>();
            energyGrid.add(rowPixels);
            for (int x = 0; x < image.getWidth(); x++) {
                int calculatedEnergy = calcEnergy(img, x, y);
                rowPixels.add(calculatedEnergy);
            }
        }
        return energyGrid;
    }

    public static int calcEnergy(Image img, int x, int y) {
//        Color imgColor = new Color(img.getRGB(x, y));
//        int green = imgColor.getGreen();
//        int blue = imgColor.getBlue();
//        int red = imgColor.getRed();

        ArrayList<Node> leftColumn = img.getLeftColumn();
        Node pixel = leftColumn.get(y);
        for (int i = 0; i < x; i++) {
            pixel = pixel.next;
        }
        int red = pixel.getColor().getRed();
        int green = pixel.getColor().getGreen();
        int blue = pixel.getColor().getBlue();

        int energy = (green + blue + red)/3;
        return energy;
    }

    public ArrayList<ArrayList<Integer>> blueGrid (Image img) {
        blueGrid = new ArrayList<>();

        ArrayList<Node> leftColumn = img.getLeftColumn();
        int height = img.getHeight();
        int width = img.getWidth();

        for (int y = 0; y < height; y++) {
            ArrayList<Integer> rowPixels = new ArrayList<>();
            Node pixel = leftColumn.get(y);
            for (int x = 0; x < width; x++) {
                int blueValue = pixel.getColor().getBlue();
                rowPixels.add(blueValue);
                pixel = pixel.next;
            }
            blueGrid.add(rowPixels);
        }
        return blueGrid;
    }

//        for (int y = 0; y < img.getHeight(); y++) {
//            ArrayList<Integer> rowPixels = new ArrayList<>();
//
//            for (int x = 0; x < img.getWidth(); x++) {
//                Color imgColor = new Color(img.getRGB(x, y));
//                int blueValue = imgColor.getBlue();
//                rowPixels.add(blueValue);
//            }
//
//            blueGrid.add(rowPixels);
//        }
//        return blueGrid;
//    }

    public void highLightBlue(ArrayList<Node> leftColumn, ArrayList<Pair> seam) {
        Image newBlueImage = new Image(leftColumn);
        int currentValueBlue = counter();
        ArrayList<Node> originalColBlue = new ArrayList<>();
        ArrayList<Pair> blueCoord =
                newBlueImage.getSeam(blueGrid(newBlueImage),
                        newBlueImage.getWidth(), newBlueImage.getHeight());
//        image.getSeam(blueGrid(getBufferImage()), image.getWidth(), image.getHeight());
//
//        List<Pair> seam = getSeam(img.blueGrid(img.getBufferedImage()), img.width, img.height);
        for (Pair coord : seam) {

            int x = coord.getCol();
            int y = coord.getRow();
            int iter = 0;

            Node pixel = leftColumn.get(y);
            while (pixel != null && iter < x) {
                pixel = pixel.next;
                iter++;
            }
            if (pixel != null && iter == x) {
                originalColBlue.add(pixel);
                pixel.setColor(Color.BLUE);
            }
        }

        BufferedImage newBufferBlue = convertToBufferImage(newBlueImage);
        saveNewImage(newBufferBlue, currentValueBlue, false);
        newStack.push(new History(blueCoord, originalColBlue));
    }

    public void highLightRed(ArrayList<Node> leftColumn, ArrayList<Pair> seam) {
//        List<Pair> seam = getSeam(img.blueGrid(img.getBufferedImage()), img.width, img.height);
        Image newRedImage = new Image(leftColumn);
        int currentValueRed = counter();
        ArrayList<Node> originalColRed = new ArrayList<>();
        ArrayList<Pair> redCoord =
                newRedImage.getSeam(energyGrid(newRedImage),
                        newRedImage.getWidth(), newRedImage.getHeight());
        for (Pair coord : seam) {

            int x = coord.getCol();
            int y = coord.getRow();
            int iter = 0;

            Node pixel = leftColumn.get(y);
            while (pixel != null && iter < x) {
                pixel = pixel.next;
                iter++;
            }
            if (pixel != null && iter == x) {
                originalColRed.add(pixel);
                pixel.setColor(Color.RED);
            }
        }
        BufferedImage newBufferRed = convertToBufferImage(newRedImage);
        saveNewImage(newBufferRed, currentValueRed, false);
        newStack.push(new History(redCoord, originalColRed));
    }

//    public void deleteSeam(ArrayList<Node> leftColumn, ArrayList<Pair> seam) {
//        ArrayList<Node> deletedNodes = new ArrayList<>();
//
//        for (Pair coord : seam) {
//
//            int x = coord.getCol();
//            int y = coord.getRow();
//            int iter = 0;
//
//            Node temp = null;
//            Node current = leftColumn.get(y);
//            temp = current;
//
//            while (current != null && iter < x - 1) {
//                temp = temp.next;
//                current = current.next;
//                iter++;
//
//            }
//                deletedNodes.add(temp.next);
//                temp.next = temp.next.next;
//            }
//        }
//        Image newDeletedSeamImg = new Image(leftColumn);

    }







//    public void undoPrevEdit() {
//        // Check if there are edits to undo
//        if (!previousValues.isEmpty() && !previousSeams.isEmpty()) {
//            // Retrieve the previous seam
//            ArrayList<Pair> previousSeam = previousSeams.remove(previousSeams.size() - 1);
//
//            // Iterate over the pixels in the seam and restore their colors
//            for (Pair pixel : previousSeam) {
//                int x = pixel.getCol();
//                int y = pixel.getRow();
//                Color color = new Color(oldImg.getRGB(x, y));
//                oldImg.setRGB(x, y, color.getRGB());
//            }
//        }
//
//
//    }



//    public void removeBluestCol(ArrayList<Node> grid) {
//        int DSheight = grid.size();
//        int DSwidth = grid.get(0).getDSWidth();
//
//        for(int y=0; y<DSheight; y++){
//            Node currentPixel = grid.get(y);
//
//            for(int x = 0; x < DSwidth; x++) {
//                while(currentPixel.next.rgb != Color.BLUE){
//                    currentPixel.next = currentPixel.next.next;
//                }
//            }
//        }
//    }

//    public void removeBluestCol(ArrayList<Node> grid) {
//        int DSheight = grid.size();
//        int DSwidth = grid.get(0).getDSWidth();
//
//        for (int y = 0; y < DSheight; y++) {
//            Node currentPixel = grid.get(y);
//            Node prevPixel = null;
//
//            for (int x = 0; x < DSwidth; x++) {
//                if (currentPixel.rgb == Color.BLUE) {
//                    if (prevPixel == null) {
//                        grid.set(y, currentPixel.next);
//                    } else {
//                        prevPixel.next = currentPixel.next;
//                    }
//                } else {
//                    prevPixel = currentPixel;
//                }
//
//                currentPixel = currentPixel.next;
//            }
//        }
//    }









