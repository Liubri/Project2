package uk.ac.nulondon;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.imageio.ImageIO;
import java.awt.Color;
public class Image {
    static ArrayList<Node> leftColumn;
    public static int width;
    public static int height;
    static UserInterface user = new UserInterface();


    private ArrayList<ArrayList<Integer>> grid;
    static ArrayList<ArrayList<EditingImage.Pair>> previousSeams;

    static ArrayList<ArrayList<EditingImage.Pair>> currentSeams;

    static double[] previousValues;

    double[] currentValues;

//    static Image image;
//    File ogFile;
//    BufferedImage oldImg;
//    BufferedImage newImg;

//    static ArrayList<ArrayList<Integer>> energyGrid;
//
//    static ArrayList<ArrayList<Integer>> blueGrid;

    public Image(ArrayList<Node> leftmostColumn) {
        leftColumn = leftmostColumn;
    }

    public int getWidth() {
        return leftColumn.get(0).getDSWidth();
    }

    public int getHeight() {
        return leftColumn.size();
    }

    public ArrayList<Node> getLeftColumn() {
        return leftColumn;
    }


    private static <T> ArrayList<T> concat(T element, Collection<? extends T> elements) {
        ArrayList<T> result = new ArrayList<>();
        result.add(element);
        result.addAll(elements);
        return result;
    }

    /**
     * Method that calculates the lowest energy seam
     * for this energy grid
     */


    public ArrayList<EditingImage.Pair> getSeam(ArrayList<ArrayList<Integer>> grid, int width, int height) {
        previousValues = new double[width];
        currentValues = new double[width];
        previousSeams = new ArrayList<>();
        currentSeams = new ArrayList<>();

        EditingImage.Pair currentPixel = new EditingImage.Pair(0, 0);

        int col = 0;

        while (col < width) {
            previousValues[col] = grid.get(0).get(col);

            previousSeams.add(concat(currentPixel, new ArrayList<>()));
            col++;
            currentPixel = new EditingImage.Pair(currentPixel.row, currentPixel.col + 1);
        }

        // compute values and paths for each row
        for (int row = 1; row < height; row++) {
            col = 0;
            currentPixel = new EditingImage.Pair(row, col);
            while (col < width) {
                double bestSoFar = previousValues[col];
                int ref = col;
                // check both adjacent pixels
                // if left exists and is better, update
                if (col > 0 && previousValues[col - 1] < bestSoFar) {
                    bestSoFar = previousValues[col - 1];
                    ref = col - 1;
                }
                // if right exists and is better, update
                if (col < width - 1 && previousValues[col + 1] < bestSoFar) {
                    bestSoFar = previousValues[col + 1];
                    ref = col + 1;
                }

                // update the value with the current pixel
                currentValues[col] = bestSoFar + grid.get(currentPixel.row).get(currentPixel.col);

                // append this new pixel to existing seams
                currentSeams.add(concat(currentPixel, previousSeams.get(ref)));

                col++;
                // move to neighbor
                currentPixel = new EditingImage.Pair(currentPixel.row, currentPixel.col + 1);
            }

            // update previous values/seams
            // and reset current values/seams
            previousValues = currentValues;
            currentValues = new double[width];
            previousSeams = currentSeams;
            currentSeams = new ArrayList<>();
        }

        // find the seam with the min sum
        double minValue = previousValues[0];
        int minIndex = 0;
        for (int i = 1; i < width; i++) {
            if (previousValues[i] < minValue) {
                minIndex = i;
                minValue = previousValues[i];
            }
        }
        return previousSeams.get(minIndex);
    }

    public ArrayList<EditingImage.Pair> getHighestValueSeam(ArrayList<ArrayList<Integer>> grid, int width, int height) {
        previousValues = new double[width];
        currentValues = new double[width];
        previousSeams = new ArrayList<>();
        currentSeams = new ArrayList<>();

        EditingImage.Pair currentPixel = new EditingImage.Pair(0, 0);

        int col = 0;

        while (col < width) {
            previousValues[col] = grid.get(0).get(col);
            previousSeams.add(concat(currentPixel, new ArrayList<>()));
            col++;
            currentPixel = new EditingImage.Pair(currentPixel.row, currentPixel.col + 1);
        }

        // compute values and paths for each row
        for (int row = 1; row < height; row++) {
            col = 0;
            currentPixel = new EditingImage.Pair(row, col);
            while (col < width) {
                double bestSoFar = previousValues[col];
                int ref = col;
                // check both adjacent pixels
                // if left exists and is better, update
                if (col > 0 && previousValues[col - 1] > bestSoFar) {
                    bestSoFar = previousValues[col - 1];
                    ref = col - 1;
                }
                // if right exists and is better, update
                if (col < width - 1 && previousValues[col + 1] > bestSoFar) {
                    bestSoFar = previousValues[col + 1];
                    ref = col + 1;
                }

                // update the value with the current pixel
                currentValues[col] = bestSoFar + grid.get(currentPixel.row).get(currentPixel.col);

                // append this new pixel to existing seams
                currentSeams.add(concat(currentPixel, previousSeams.get(ref)));

                col++;
                // move to neighbor
                currentPixel = new EditingImage.Pair(currentPixel.row, currentPixel.col + 1);
            }

            // update previous values/seams
            // and reset current values/seams
            previousValues = currentValues;
            currentValues = new double[width];
            previousSeams = currentSeams;
            currentSeams = new ArrayList<>();
        }

        // find the seam with the max sum
        double maxValue = previousValues[0];
        int maxIndex = 0;
        for (int i = 1; i < width; i++) {
            if (previousValues[i] > maxValue) {
                maxIndex = i;
                maxValue = previousValues[i];
            }
        }
        return previousSeams.get(maxIndex);
    }





//    public Image(String filePath) {
//        try {
//            ogFile = new File(filePath);
//            oldImg = ImageIO.read(ogFile);
//            width = oldImg.getWidth();
//            height = oldImg.getHeight();
//        } catch (IOException e) {
//            System.out.println("Error loading image: " + e.getMessage());
//        }
//    }

//    public Image(BufferedImage oldImg){
//        this.oldImg = oldImg;
//        width = oldImg.getWidth();
//        height = oldImg.getHeight();
//    }

//    public ArrayList<Node> convertToDS(BufferedImage image) {
//        ArrayList<Node> leftColumn = new ArrayList<>();
//
//        // Iterate over each pixel in the image
//        for (int y = 0; y < image.getHeight(); y++) {
//            Color colorCol = new Color(image.getRGB(0, y)); // Color of the leftmost pixel in the row
//            Node leftMostNode = new Node(0, y, colorCol); // Create a new node for the leftmost pixel
//            leftColumn.add(leftMostNode); // Add the leftmost node to the left column
//
//            // Iterate over each pixel in the row (excluding the leftmost pixel)
//            for (int x = 1; x < image.getWidth(); x++) {
//                Color colorRow = new Color(image.getRGB(x, y)); // Color of the current pixel
//                leftMostNode.addNode(x, y, colorRow); // Add a new node for the current pixel to the leftmost node
//            }
//        }
//
//        return leftColumn;
//    }



//    public BufferedImage getBufferedImage() {
//        return oldImg;
//    }

//    public ArrayList<ArrayList<Integer>> energyGrid (BufferedImage img) {
//        energyGrid = new ArrayList<>();
//        for (int y = 0; y < height; y++) {
//            ArrayList<Integer> rowPixels = new ArrayList<Integer>();
//            energyGrid.add(rowPixels);
//            for (int x = 0; x < width; x++) {
//                int calculatedEnergy = calcEnergy(img, x, y);
//                rowPixels.add(calculatedEnergy);
//            }
//        }
//        return energyGrid;
//    }
//
//    public static int calcEnergy(BufferedImage img, int x, int y) {
//        Color imgColor = new Color(img.getRGB(x, y));
//        int green = imgColor.getGreen();
//        int blue = imgColor.getBlue();
//        int red = imgColor.getRed();
//
//        int energy = (green + blue + red)/3;
//
//        return energy;
//    }
//
//    public ArrayList<ArrayList<Integer>> blueGrid (BufferedImage img) {
//        blueGrid = new ArrayList<>();
//
//        for (int y = 0; y < height; y++) {
//            ArrayList<Integer> rowPixels = new ArrayList<>();
//
//            for (int x = 0; x < width; x++) {
//                Color imgColor = new Color(img.getRGB(x, y));
//                int blueValue = imgColor.getBlue();
//                rowPixels.add(blueValue);
//            }
//
//            blueGrid.add(rowPixels);
//        }
//        return blueGrid;
//    }

    public void deleteSeam(ArrayList<Node> leftColumn, ArrayList<EditingImage.Pair> seam) {
        ArrayList<Node> deletedNodes = new ArrayList<>();
        for (EditingImage.Pair coord : seam) {

            int x = coord.getCol();
            int y = coord.getRow();
            int iter = 0;

            Node temp = null;
            Node current = leftColumn.get(y);
            temp = current;

            while (current != null && iter < x - 1) {
                temp = temp.next;
                current = current.next;
                iter++;

            }
            deletedNodes.add(temp.next);
            temp.next = temp.next.next;
        }
        Image newDeletedSeamImg = new Image(leftColumn);
        int currentValueDeleted = user.editor.counter();
        BufferedImage newBufferDeleted = user.editor.convertToBufferImage(newDeletedSeamImg);

        if (!user.isFinalVersion) {
        user.editor.saveNewImage(newBufferDeleted, currentValueDeleted, false);
    }
        else {
        user.editor.saveNewImage(newBufferDeleted, currentValueDeleted, true);
    }
        user.editor.newStack.push(new History(seam, deletedNodes));
}

    public Image reinsertNodes(ArrayList<EditingImage.Pair> coords, ArrayList<Node> deletedNodes) {
        for (Node node : deletedNodes) {
            int x = node.getNodeX();
            int y = node.getNodeY();

            Node prevX = null;
            Node prevY = null;
            for (Node current : leftColumn) {
                if (current.getNodeX() == x - 1) {
                    prevX = current;
                }
                if (current.getNodeY() == y - 1) {
                    prevY = current;
                }
            }

            Node newNode = new Node(x, y, node.getColor());
            newNode.next = prevX.next;
            prevX.next = newNode;
            prevY.next = newNode;
        }
        return new Image(leftColumn);
    }


    public Image reColorNodes(ArrayList<EditingImage.Pair> coords, ArrayList<Node> deletedNodes) {
        for (Node node : deletedNodes) {
            int x = node.getNodeX();
            int y = node.getNodeY();

            Node targetNode = null;
            for (Node current : leftColumn) {
                if (current.getNodeX() == x && current.getNodeY() == y) {
                    targetNode = current;
                    break;
                }
            }

            if (targetNode != null) {
                targetNode.setColor(node.getColor());
            }
        }
        return new Image(leftColumn);
    }
//        for (Node node : deletedNodes) {
//            int x = node.getNodeX();
//            int y = node.getNodeY();
//
//            Node prevX = null;
//            Node prevY = null;
//            for (Node current : leftColumn) {
//                if (current.getNodeX() == x - 1) {
//                    prevX = current;
//                }
//                if (current.getNodeY() == y - 1) {
//                    prevY = current;
//                }
//            }
//
//            Node newNode = new Node(x, y, node.getColor());
//            newNode.next = prevX.next;
//            prevX.next = newNode;
//            prevY.next = newNode;
//        }
//        return new Image(leftColumn);
        }

