package uk.ac.nulondon;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class DeleteTest {
    public static void main(String[] args) throws IOException {

//    public void deleteBlueSeam() throws IOException {
        //delete blue seam
        String filePath = "src/main/resources/Beach.png";
        EditingImage editImg = new EditingImage(filePath);
        Image img = editImg.getImage();
        BufferedImage testImage = editImg.getBufferImage();


        //BufferedImage testImage = ImageIO.read(new File(filePath));
//        Image image = new Image(new EditingImage(filepath));
//        Image image = new Image(testImage.getLeftColumn);
        //EditingImage editingImage = new EditingImage(image);

        int width = img.getWidth();
        int height = img.getHeight();

        ArrayList<ArrayList<Integer>> blueGridTest = editImg.blueGrid(img);
        ArrayList<Node> testDS = editImg.convertToDS(testImage);
        ArrayList<EditingImage.Pair> testSeam = img.getHighestValueSeam(blueGridTest, width, height);
        img.deleteSeam(testDS, testSeam);
        BufferedImage deleteBlueImg = editImg.convertToBufferImage(img);

//        String outputFilePath = "src/main/resources/BeachBlueDeleted.png";
//        File outputImage = new File(outputFilePath);
//        ImageIO.write(deleteBlueImg, "png", outputImage);


//    //delete red seam
//
//    ArrayList<ArrayList<Integer>> energyGridTest = image.energyGrid(testImage);
//    ArrayList<Node> testDS2 = image.convertToDS(testImage);
//    ArrayList<EditingImage.Pair> testSeam2 = editingImage.getHighestValueSeam(energyGridTest, width, height);
//        editingImage.deleteSeam(testDS2, testSeam2);
//    BufferedImage deleteRedImg = editingImage.convertToBufferImage(testDS2);
//
//    String outputFilePath2 = "src/main/resources/BeachRedDeleted.png";
//    File outputImage2 = new File(outputFilePath2);
//        ImageIO.write(deleteRedImg, "png", outputImage2);
//    }
    }
}


