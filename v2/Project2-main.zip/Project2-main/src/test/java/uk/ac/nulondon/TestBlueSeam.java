package uk.ac.nulondon;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.imageio.ImageIO;

public class TestBlueSeam {
    public static void main(String[] args) throws IOException {

        //String Filepath = "src/main/resources/Beach.png";
        //BufferedImage testImage = ImageIO.read(new File(Filepath));

        String filePath = "src/main/resources/Beach.png";
//        BufferedImage testImage = ImageIO.read(new File(Filepath));

        //String filePath = "src/main/resources/Beach.png";
        EditingImage editImg = new EditingImage(filePath);
        Image image = editImg.getImage();
        BufferedImage testImage = editImg.getBufferImage();

//        Image image = new Image(testImage); // Create an instance of Image with BufferedImage
//        EditingImage editingImage = new EditingImage(image);
        int width = testImage.getWidth();
        int height = testImage.getHeight();

        ArrayList<ArrayList<Integer>> redgridTest = editImg.blueGrid(image);
        ArrayList<Node> testDS = editImg.convertToDS(testImage);
        ArrayList<EditingImage.Pair> testSeam = image.getSeam(redgridTest, width, height);

        editImg.highLightBlue(testDS, testSeam);

//        BufferedImage testImage2 = editImg.convertToBufferImage(testDS);
//
//        String filePath2 = "src/main/resources/BeachBlue.png"; // Change this to the desired path
//        File outputImage = new File(filePath2);
//        ImageIO.write(testImage2, "png", outputImage);

    }
}


//        Image image = new Image(testImage); // Create an instance of Image with BufferedImage
//        EditingImage editingImage = new EditingImage(image);
//        int width = testImage.getWidth();
//        int height = testImage.getHeight();
//
//        ArrayList<ArrayList<Integer>> bluegridTest = image.blueGrid(testImage);
//        ArrayList<Node> testDS = image.convertToDS(testImage);
//        ArrayList<EditingImage.Pair> testSeam = editingImage.getHighestValueSeam(bluegridTest, width, height);
//
//        editingImage.highLightBlue(testDS, testSeam);
//
//        BufferedImage testImage2 = editingImage.convertToBufferImage(testDS);
//
//
//        String filePath = "src/main/resources/BeachBlue.png"; // Change this to the desired path
//        File outputImage = new File(filePath);
//        ImageIO.write(testImage2,"png", outputImage);
//



//    public static void printArrayList(ArrayList<ArrayList<Integer>> arrayList) {
//        for (ArrayList<Integer> innerList : arrayList) {
//            for (Integer value : innerList) {
//                System.out.print(value + " ");
//            }
//            System.out.println();
//        }
//    }
//    public static void main(String[] args) throws IOException {
//
//        String Filepath = "src/main/resources/Beach.png";
//        BufferedImage testImage = ImageIO.read(new File(Filepath));
//
//
//        Image image = new Image(testImage); // Create an instance of Image with BufferedImage
//        EditingImage editingImage = new EditingImage(image);
//        int width = testImage.getWidth();
//        int height = testImage.getHeight();
//
//        ArrayList<ArrayList<Integer>> bluegridTest = image.blueGrid(testImage);
//
//        printArrayList(bluegridTest);
//    }

